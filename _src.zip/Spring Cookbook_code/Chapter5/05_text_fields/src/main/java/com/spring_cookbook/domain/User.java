package com.spring_cookbook.domain;

public class User {

	private String firstName1;
	private String firstName2;
	private String firstName3;
	private String firstName4;
	
	public String getFirstName1() {
		return firstName1;
	}
	public void setFirstName1(String firstName1) {
		this.firstName1 = firstName1;
	}
	public String getFirstName2() {
		return firstName2;
	}
	public void setFirstName2(String firstName2) {
		this.firstName2 = firstName2;
	}
	public String getFirstName3() {
		return firstName3;
	}
	public void setFirstName3(String firstName3) {
		this.firstName3 = firstName3;
	}
	public String getFirstName4() {
		return firstName4;
	}
	public void setFirstName4(String firstName4) {
		this.firstName4 = firstName4;
	}
		

	
}
package com.spring_cookbook.util;

public class StringUtil {
	public String concat(String a, String b) {
		return a + b;
	}
}

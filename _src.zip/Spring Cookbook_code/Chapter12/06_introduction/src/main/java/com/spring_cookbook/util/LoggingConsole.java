package com.spring_cookbook.util;

public class LoggingConsole implements Logging {

	public void log(String str) {
		System.out.println(str);
	}

}

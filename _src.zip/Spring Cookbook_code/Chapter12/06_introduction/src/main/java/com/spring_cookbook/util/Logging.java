package com.spring_cookbook.util;

public interface Logging {
	public void log(String str);
}

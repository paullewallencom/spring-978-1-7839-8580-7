package com.springcookbook.service;

import org.springframework.stereotype.Component;

@Component
public class UserService {
	public int findNumberOfUsers() {
		return 10;
	}
}
